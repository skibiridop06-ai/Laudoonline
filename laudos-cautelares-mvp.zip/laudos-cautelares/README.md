# Laudos Cautelares — MVP

Plataforma web (Next.js + PostgreSQL + IA de visão) para o fluxo: perito envia fotos pelo celular → IA classifica e extrai dados → sede confere e registra consultas → laudo preliminar em PDF → admin aprova → laudo final com código de validação.

## Rodar localmente
Requisitos: Node 20+, Docker (para o PostgreSQL).

```bash
cp .env.example .env          # edite AUTH_SECRET, FILE_SIGNING_SECRET e ANTHROPIC_API_KEY
docker compose up -d db
npm install
npx playwright install chromium   # necessário para gerar o PDF
npm run setup                     # cria tabelas + usuários de demonstração
npm run dev                       # http://localhost:3000
npm test                          # testes das regras
```
Gere segredos com `openssl rand -hex 32`.

Usuários de demonstração (fictícios; senha em `SEED_PASSWORD`, padrão `Demo@12345`):
`perito@demo.local`, `sede@demo.local`, `admin@demo.local`. **Troque/desative em produção.**

## Fluxo de teste ponta a ponta
1. Entre como **perito** → abra a vistoria demo (ou crie uma) → "Tirar foto"/"Enviar da galeria".
2. A IA classifica cada foto; "Pendências" lista as fotos obrigatórias que faltam ou estão ilegíveis.
3. Entre como **sede** → confira/corrija campos extraídos (só "Confirmado" vira fato no laudo) → registre consultas com fonte, data e comprovante → "Gerar laudo preliminar" → redija a conclusão → "Enviar para revisão".
4. Entre como **admin** → "Aprovar e emitir versão final" (bloqueia se faltar foto obrigatória, campo não confirmado ou conclusão) ou "Devolver".
5. O PDF final traz revisor, data, versão e código; valide em `/validar/<código>`.

## Publicar na internet
Precisa de servidor Node **persistente** (a fila de análise roda em memória e o PDF usa Chromium) — VPS, Railway, Render ou Fly.io. **Não use serverless (Vercel).**
- Use o `Dockerfile` (instala Chromium). Variáveis: as do `.env.example`, com `APP_URL` = domínio público.
- **HTTPS obrigatório** (o cookie de sessão é `secure` em produção).
- PostgreSQL gerenciado + **volume persistente** montado em `STORAGE_DIR` (ou troque `src/lib/storage.ts` por S3/R2).
- Backups: `pg_dump` diário do banco + snapshot do volume de arquivos.

## O que está operacional
Login/perfis (perito, sede, admin) · cadastro de vistoria · upload multi-foto/câmera com validação e re-codificação · links temporários assinados · classificação, qualidade, OCR e descrição por IA · detecção de duplicadas (hash exato) · pendências · conferência de campos · importação manual de consultas (4 estados + comprovante) · PDF preliminar e final · versionamento · revisão/aprovação/devolução · código de validação público · dashboard com filtros · auditoria · gestão de usuários.

## Depende de serviço externo
- **IA**: `ANTHROPIC_API_KEY` (pago). Sem a chave nada é simulado: as fotos ficam "Classifique manualmente".
- **Consultas veiculares**: não há integração conectada. Contrate um fornecedor autorizado e implemente um conector (ponto de extensão: `src/app/api/vistorias/[id]/consultas`). Hoje é importação manual.

## Exige validação humana (por design)
Todo campo extraído, a categoria sugerida das fotos, a descrição dos achados e a conclusão técnica. A IA nunca declara chassi original/adulterado — só aponta indícios.

## Ainda NÃO implementado (próximas versões)
Tela de configuração de modelos/fotos obrigatórias (hoje em `src/lib/categorias.ts`) · QR Code (há link/código de validação) · fila BullMQ/Redis · S3 · job automático de retenção/exclusão LGPD · detecção de duplicadas por similaridade (só hash idêntico) · redefinição de senha por e-mail · entrega do laudo ao cliente por e-mail/WhatsApp (hoje: download).
**LGPD:** defina base legal, política de retenção e DPO com seu jurídico; o sistema registra auditoria e restringe acesso, mas a política é da empresa.

> Este código foi escrito sem acesso à rede para `npm install`; rode `npm run build` e `npm test` na primeira execução e corrija eventuais ajustes finos.

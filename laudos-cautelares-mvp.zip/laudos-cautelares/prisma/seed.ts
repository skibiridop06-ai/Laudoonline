// Dados de DEMONSTRAÇÃO — todos fictícios.
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
const prisma = new PrismaClient();

async function main() {
  const senha = await bcrypt.hash(process.env.SEED_PASSWORD || 'Demo@12345', 12);
  const mk = (nome: string, email: string, role: 'PERITO' | 'SEDE' | 'ADMIN') =>
    prisma.user.upsert({ where: { email }, update: {}, create: { nome, email, senhaHash: senha, role, unidade: 'Unidade Demo' } });
  const admin = await mk('Admin Demo (fictício)', 'admin@demo.local', 'ADMIN');
  await mk('Atendente Sede Demo (fictício)', 'sede@demo.local', 'SEDE');
  const perito = await mk('Perito Demo (fictício)', 'perito@demo.local', 'PERITO');
  if (!(await prisma.vistoria.findFirst({ where: { demo: true } }))) {
    await prisma.vistoria.create({ data: { placa: 'DEM0A00', marca: 'MarcaFictícia', modelo: 'ModeloDemo 1.0', anoFab: 2020, anoModelo: 2021, cor: 'Prata', cliente: 'Cliente Fictício (demo)', local: 'Local fictício', demo: true, peritoId: perito.id } });
  }
  console.log('Seed ok. Usuários: admin@demo.local, sede@demo.local, perito@demo.local');
  void admin;
}
main().finally(() => prisma.$disconnect());

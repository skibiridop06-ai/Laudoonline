const COR: Record<string, string> = {
  APROVADO: 'bg-green-100 text-ok', CONFIRMADO: 'bg-green-100 text-ok', POSITIVO: 'bg-amber-100 text-warn', NEGATIVO: 'bg-green-100 text-ok',
  EM_REVISAO: 'bg-blue-100 text-blue-800', EM_CONFERENCIA: 'bg-blue-100 text-blue-800', EM_ANALISE: 'bg-slate-200 text-slate-700',
  FOTOS_PENDENTES: 'bg-amber-100 text-warn', DEVOLVIDO: 'bg-red-100 text-bad', PRELIMINAR: 'bg-slate-200 text-slate-700',
  IDENTIFICADO: 'bg-amber-100 text-warn', NECESSITA_CONFERENCIA: 'bg-amber-100 text-warn', NAO_IDENTIFICADO: 'bg-red-100 text-bad',
  INDISPONIVEL: 'bg-slate-200 text-slate-700', INCONCLUSIVO: 'bg-amber-100 text-warn',
};
export function Badge({ k, children }: { k: string; children: React.ReactNode }) {
  return <span className={`inline-block rounded px-2 py-0.5 text-xs font-semibold ${COR[k] || 'bg-slate-200 text-slate-700'}`}>{children}</span>;
}

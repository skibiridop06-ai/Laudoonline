'use client';
export default function Logout() {
  return <button className="text-sm underline" onClick={async () => { await fetch('/api/logout', { method: 'POST' }); location.href = '/login'; }}>Sair</button>;
}

import { prisma } from './db';
import { HttpError } from './api';
import type { SessionUser } from './auth';

export async function vistoriaDoUsuario(id: string, u: SessionUser) {
  const v = await prisma.vistoria.findUnique({ where: { id } });
  if (!v || (u.role === 'PERITO' && v.peritoId !== u.id)) throw new HttpError(404, 'Vistoria não encontrada');
  return v;
}

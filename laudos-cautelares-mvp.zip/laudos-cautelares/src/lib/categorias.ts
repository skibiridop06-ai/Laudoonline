export const CATEGORIAS: Record<string, string> = {
  FRONTAL: 'Vista frontal',
  TRASEIRA: 'Vista traseira',
  LATERAL_DIREITA: 'Lateral direita',
  LATERAL_ESQUERDA: 'Lateral esquerda',
  PAINEL_HODOMETRO: 'Painel e hodômetro',
  PLACA: 'Placa',
  CHASSI_VIN: 'Chassi / VIN',
  MOTOR_IDENTIFICACAO: 'Identificação do motor',
  ETIQUETAS: 'Etiquetas identificadoras',
  GRAVACAO_VIDROS: 'Gravações nos vidros',
  ESTRUTURAL: 'Colunas, longarinas e estrutura',
  COMPARTIMENTO_MOTOR: 'Compartimento do motor',
  PORTA_MALAS: 'Porta-malas',
  COMPLEMENTAR: 'Complementar',
  DIVERGENCIA_DANO: 'Divergência ou dano',
  NAO_IDENTIFICADA: 'Não identificada',
};

// Padrão do MVP (configurável via código; tela de configuração fica para a v2)
export const OBRIGATORIAS = [
  'FRONTAL', 'TRASEIRA', 'LATERAL_DIREITA', 'LATERAL_ESQUERDA', 'PAINEL_HODOMETRO',
  'PLACA', 'CHASSI_VIN', 'MOTOR_IDENTIFICACAO', 'COMPARTIMENTO_MOTOR', 'PORTA_MALAS',
];

export const CAMPOS: Record<string, string> = {
  placa: 'Placa (lida na foto)',
  hodometro: 'Quilometragem (hodômetro)',
  vin: 'Chassi / VIN',
  motor: 'Número do motor',
  etiqueta: 'Etiqueta identificadora',
};

export const STATUS_VISTORIA: Record<string, string> = {
  FOTOS_PENDENTES: 'Fotos pendentes', EM_ANALISE: 'Em análise (IA)', EM_CONFERENCIA: 'Em conferência',
  EM_REVISAO: 'Em revisão', APROVADO: 'Aprovado', DEVOLVIDO: 'Devolvido',
};
export const STATUS_LAUDO: Record<string, string> = {
  PRELIMINAR: 'Preliminar', EM_REVISAO: 'Em revisão', APROVADO: 'Aprovado (final)', DEVOLVIDO: 'Devolvido',
};
export const STATUS_CAMPO: Record<string, string> = {
  CONFIRMADO: 'Confirmado', IDENTIFICADO: 'Identificado pela IA — aguardando conferência',
  NECESSITA_CONFERENCIA: 'Necessita de conferência', NAO_IDENTIFICADO: 'Não identificado',
};
export const CONSULTA_TIPOS: Record<string, string> = {
  CADASTRAL: 'Identificação cadastral', LEILAO: 'Leilão', SINISTRO: 'Sinistro', ROUBO_FURTO: 'Roubo ou furto',
  RESTRICOES: 'Restrições administrativas/judiciais', INDENIZACAO: 'Indenização', DANOS: 'Histórico de danos/ocorrências',
};
export const CONSULTA_RESULTADOS: Record<string, string> = {
  POSITIVO: 'Positivo — registro identificado na fonte',
  NEGATIVO: 'Negativo — a fonte não retornou registro',
  INDISPONIVEL: 'Indisponível — consulta não realizada',
  INCONCLUSIVO: 'Inconclusivo — sem conclusão segura',
};

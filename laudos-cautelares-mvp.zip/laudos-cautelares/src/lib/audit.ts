import { prisma } from './db';
export async function auditar(userId: string | null, acao: string, entidade: string, entidadeId: string, detalhes?: unknown) {
  await prisma.auditoria.create({ data: { userId, acao, entidade, entidadeId, detalhes: detalhes === undefined ? undefined : (detalhes as any) } });
}

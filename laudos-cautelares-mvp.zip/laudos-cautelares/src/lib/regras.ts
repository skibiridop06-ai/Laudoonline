// Regras puras (sem banco) — cobertas por testes.
import { OBRIGATORIAS } from './categorias';

export function normalizaPlaca(s: string) {
  return (s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
}
export function placaValida(s: string) {
  return /^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(normalizaPlaca(s));
}
export function placaDivergente(lida?: string | null, cadastro?: string | null) {
  if (!lida || !cadastro) return false;
  return normalizaPlaca(lida) !== normalizaPlaca(cadastro);
}
export function statusCampo(valor: string | null | undefined, confianca: number) {
  if (!valor || !valor.trim()) return 'NAO_IDENTIFICADO';
  return confianca >= 0.85 ? 'IDENTIFICADO' : 'NECESSITA_CONFERENCIA';
}
export type FotoRegra = { categoria: string | null; legivel: boolean; duplicada: boolean };
export function faltantes(fotos: FotoRegra[], obrigatorias: string[] = OBRIGATORIAS) {
  const ok = new Set(fotos.filter((f) => f.legivel && !f.duplicada && f.categoria).map((f) => f.categoria as string));
  return obrigatorias.filter((c) => !ok.has(c));
}
// A sugestão da IA só conta com confiança >= 0.7; categoria confirmada por humano sempre conta.
export function paraRegra(f: { categoriaConfirmada: string | null; categoriaSugerida: string | null; confCategoria: number | null; legivel: boolean | null; duplicadaDe: string | null }): FotoRegra {
  if (f.categoriaConfirmada) return { categoria: f.categoriaConfirmada, legivel: true, duplicada: !!f.duplicadaDe };
  const sug = f.categoriaSugerida && (f.confCategoria ?? 0) >= 0.7 ? f.categoriaSugerida : null;
  return { categoria: sug, legivel: f.legivel === true, duplicada: !!f.duplicadaDe };
}
// Campo só é "fato" no laudo quando CONFIRMADO. NAO_IDENTIFICADO aparece como limitação.
export function camposPendentes(campos: { status: string }[]) {
  return campos.filter((c) => c.status === 'IDENTIFICADO' || c.status === 'NECESSITA_CONFERENCIA');
}

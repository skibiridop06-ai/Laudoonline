import { prisma } from './db';
import { ler } from './storage';
import { analisarImagem } from './ai';
import { faltantes, paraRegra, placaDivergente, statusCampo } from './regras';

export async function recalcular(vistoriaId: string) {
  const v = await prisma.vistoria.findUnique({ where: { id: vistoriaId }, include: { fotos: true } });
  if (!v || v.status === 'EM_REVISAO' || v.status === 'APROVADO') return;
  const naoProc = v.fotos.some((f) => !f.processada);
  const falt = faltantes(v.fotos.map(paraRegra));
  const ilegiveis = v.fotos.some((f) => f.legivel === false && !f.categoriaConfirmada && !f.duplicadaDe);
  const status = naoProc ? 'EM_ANALISE' : falt.length || ilegiveis ? 'FOTOS_PENDENTES' : 'EM_CONFERENCIA';
  if (status !== v.status) await prisma.vistoria.update({ where: { id: v.id }, data: { status } });
}

export async function processarFoto(id: string) {
  const f = await prisma.foto.findUnique({ where: { id }, include: { vistoria: true } });
  if (!f) return;
  try {
    const a = await analisarImagem(await ler(f.chave));
    await prisma.foto.update({ where: { id }, data: {
      categoriaSugerida: a.categoria === 'NAO_IDENTIFICADA' ? null : a.categoria, confCategoria: a.confiancaCategoria,
      nitidez: a.qualidade.nitidez, iluminacao: a.qualidade.iluminacao, enquadramento: a.qualidade.enquadramento,
      legivel: a.legivel, descricao: a.descricao, indicios: a.indiciosVisuais ?? null, processada: true, erro: null,
    } });
    for (const c of a.campos) {
      const atual = await prisma.campo.findUnique({ where: { vistoriaId_chave: { vistoriaId: f.vistoriaId, chave: c.chave } } });
      if (atual?.status === 'CONFIRMADO') continue;
      if (atual?.valor && atual.confianca >= c.confianca) continue;
      if (!c.valor && atual) continue;
      const dados = { valor: c.valor, confianca: c.confianca, status: statusCampo(c.valor, c.confianca), origem: 'FOTO', fotoId: f.id };
      await prisma.campo.upsert({ where: { vistoriaId_chave: { vistoriaId: f.vistoriaId, chave: c.chave } }, update: dados, create: { vistoriaId: f.vistoriaId, chave: c.chave, ...dados } });
      if (c.chave === 'placa' && c.valor && placaDivergente(c.valor, f.vistoria.placa)) {
        const d = { valor: `Foto: ${c.valor} | Cadastro: ${f.vistoria.placa}`, confianca: c.confianca, status: 'NECESSITA_CONFERENCIA', origem: 'FOTO', fotoId: f.id };
        await prisma.campo.upsert({ where: { vistoriaId_chave: { vistoriaId: f.vistoriaId, chave: 'divergencia_placa' } }, update: d, create: { vistoriaId: f.vistoriaId, chave: 'divergencia_placa', ...d } });
      }
    }
  } catch (e: any) {
    console.error('[processarFoto]', id, e?.message);
    await prisma.foto.update({ where: { id }, data: { processada: true, erro: e?.message === 'IA_NAO_CONFIGURADA'
      ? 'IA não configurada (ANTHROPIC_API_KEY ausente). Classifique manualmente.'
      : 'Falha na análise automática. Reprocese ou classifique manualmente.' } });
  }
  await recalcular(f.vistoriaId);
}

import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { prisma } from './db';
import { HttpError } from './api';

export type Role = 'PERITO' | 'SEDE' | 'ADMIN';
export type SessionUser = { id: string; nome: string; email: string; role: Role };
const key = () => new TextEncoder().encode(process.env.AUTH_SECRET);

export async function criarSessao(userId: string) {
  const token = await new SignJWT({}).setProtectedHeader({ alg: 'HS256' }).setSubject(userId).setExpirationTime('8h').sign(key());
  cookies().set('sess', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/', maxAge: 8 * 3600 });
}
export function encerrarSessao() { cookies().delete('sess'); }

export async function getUser(): Promise<SessionUser | null> {
  const t = cookies().get('sess')?.value;
  if (!t) return null;
  try {
    const { payload } = await jwtVerify(t, key());
    const u = await prisma.user.findUnique({ where: { id: payload.sub! } });
    if (!u || !u.ativo) return null;
    return { id: u.id, nome: u.nome, email: u.email, role: u.role as Role };
  } catch { return null; }
}
export async function requireUser(roles?: Role[]) {
  const u = await getUser();
  if (!u) throw new HttpError(401, 'Não autenticado');
  if (roles && !roles.includes(u.role)) throw new HttpError(403, 'Sem permissão');
  return u;
}

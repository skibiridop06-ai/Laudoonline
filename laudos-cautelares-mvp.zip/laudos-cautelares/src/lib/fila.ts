// Fila em memória (concorrência 3). Requer servidor Node persistente (VPS/Docker/Railway).
// Para escala/serverless, troque por BullMQ + Redis mantendo enfileirar().
const q: (() => Promise<void>)[] = [];
let rodando = 0;
const MAX = 3;
export function enfileirar(fn: () => Promise<void>) { q.push(fn); tick(); }
function tick() {
  while (rodando < MAX && q.length) {
    const f = q.shift()!;
    rodando++;
    f().catch((e) => console.error('[fila]', e)).finally(() => { rodando--; tick(); });
  }
}

import { chromium } from 'playwright';
import { prisma } from './db';
import { ler, salvar, remover } from './storage';
import { CATEGORIAS, CAMPOS, CONSULTA_TIPOS, CONSULTA_RESULTADOS, STATUS_CAMPO } from './categorias';

const esc = (s: unknown) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
const dt = (d: Date) => d.toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
const dia = (d: Date) => d.toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' });
const ORIGEM: Record<string, string> = { FOTO: 'Fotografia', CADASTRO: 'Cadastro', CONSULTA: 'Consulta externa', HUMANO: 'Inserção humana' };

export async function renderizarLaudo(laudoId: string) {
  const l = await prisma.laudo.findUniqueOrThrow({ where: { id: laudoId } });
  const v = await prisma.vistoria.findUniqueOrThrow({ where: { id: l.vistoriaId }, include: { fotos: { orderBy: { createdAt: 'asc' } }, campos: true, consultas: { orderBy: { dataConsulta: 'asc' } }, perito: true } });
  const revisor = l.revisorId ? await prisma.user.findUnique({ where: { id: l.revisorId } }) : null;
  const final = l.status === 'APROVADO';
  const cor = process.env.EMPRESA_COR || '#0F4C5C';
  const base = process.env.APP_URL || 'http://localhost:3000';

  // Fotos por categoria (sem duplicadas)
  const grupos: Record<string, string[]> = {};
  for (const f of v.fotos.filter((x) => !x.duplicadaDe)) {
    const cat = f.categoriaConfirmada ?? (f.categoriaSugerida && (f.confCategoria ?? 0) >= 0.7 ? f.categoriaSugerida : 'NAO_IDENTIFICADA');
    const b64 = (await ler(f.chave)).toString('base64');
    (grupos[cat] ||= []).push(`<figure><img src="data:image/jpeg;base64,${b64}"/><figcaption>${esc(f.descricao || '')}${f.categoriaConfirmada ? '' : ' <i>(categoria sugerida pela IA)</i>'}</figcaption></figure>`);
  }

  const cadastro: [string, unknown][] = [
    ['Placa (cadastro)', v.placa], ['Marca', v.marca], ['Modelo', v.modelo],
    ['Ano fabricação / modelo', [v.anoFab, v.anoModelo].filter(Boolean).join(' / ')], ['Cor', v.cor],
    ['Cliente', v.cliente], ['Local da vistoria', v.local], ['Data da vistoria', dia(v.createdAt)], ['Perito', v.perito.nome],
  ];
  const linhasCad = cadastro.map(([k, x]) => `<tr><td>${k}</td><td>${esc(x) || '<span class="pend">não informado</span>'}</td><td>Cadastro</td></tr>`).join('');

  const linhasCampos = Object.entries(CAMPOS).map(([k, rot]) => {
    const c = v.campos.find((x) => x.chave === k);
    if (!c || !c.valor) return `<tr><td>${rot}</td><td><span class="pend">NÃO IDENTIFICADO</span></td><td>—</td></tr>`;
    const ok = c.status === 'CONFIRMADO';
    return `<tr><td>${rot}</td><td>${esc(c.valor)} ${ok ? '' : `<span class="pend">PENDENTE — ${esc(STATUS_CAMPO[c.status])}</span>`}</td><td>${ORIGEM[c.origem] || c.origem}</td></tr>`;
  }).join('');

  const diverg = [
    ...v.campos.filter((c) => c.chave.startsWith('divergencia_')).map((c) => `Divergência de placa: ${esc(c.valor)} (${esc(STATUS_CAMPO[c.status])})`),
    ...v.fotos.filter((f) => (f.categoriaConfirmada || f.categoriaSugerida) === 'DIVERGENCIA_DANO' && !f.duplicadaDe).map((f) => esc(f.descricao || 'Foto de divergência/dano')),
    ...v.fotos.filter((f) => f.indicios && !f.duplicadaDe).map((f) => `Indício visual (análise humana necessária): ${esc(f.indicios)}`),
  ];

  const linhasCons = v.consultas.map((c) => `<tr><td>${CONSULTA_TIPOS[c.tipo] || c.tipo}</td><td>${esc(CONSULTA_RESULTADOS[c.resultado] || c.resultado)}${c.detalhes ? `<br/><small>${esc(c.detalhes)}</small>` : ''}</td><td>${esc(c.fonte)} — ${dia(c.dataConsulta)}</td></tr>`).join('');

  const achados = v.fotos.filter((f) => f.descricao && !f.duplicadaDe).map((f) => `<li>${esc(f.descricao)}</li>`).join('');

  const html = `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"/><style>
  @page{size:A4;margin:16mm 14mm 18mm}
  body{font-family:Arial,Helvetica,sans-serif;font-size:10.5pt;color:#14212B;line-height:1.35}
  header{display:flex;justify-content:space-between;border-bottom:3px solid ${cor};padding-bottom:8px;margin-bottom:14px}
  header h1{margin:0;font-size:16pt;color:${cor}} header small{color:#555}
  h2{font-size:12pt;color:${cor};border-bottom:1px solid #ccd;padding-bottom:3px;margin:18px 0 6px}
  table{width:100%;border-collapse:collapse} td,th{border:1px solid #ccd;padding:4px 6px;vertical-align:top;text-align:left;font-size:9.5pt}
  td:first-child{width:32%;background:#f3f6f8} .pend{color:#B45309;font-weight:bold}
  .grid{display:flex;flex-wrap:wrap;gap:6px} figure{margin:0;width:48%;break-inside:avoid} figure img{width:100%;border:1px solid #ccd}
  figcaption{font-size:8pt;color:#555} .aviso{background:#fff7ed;border:1px solid #fdba74;padding:6px 8px;font-size:9pt}
  .marca{position:fixed;top:40%;left:5%;font-size:90pt;color:rgba(180,83,9,.12);transform:rotate(-30deg);z-index:-1}
  footer{margin-top:20px;font-size:9pt;border-top:1px solid #ccd;padding-top:6px}
  </style></head><body>
  ${final ? '' : '<div class="marca">PRELIMINAR</div>'}
  <header><div><h1>${esc(process.env.EMPRESA_NOME || 'Empresa')}</h1><small>${esc(process.env.EMPRESA_DADOS || '')}</small></div>
  <div style="text-align:right"><b>LAUDO CAUTELAR VEICULAR</b><br/>Nº ${esc(l.numero)} — versão ${l.versao}<br/>OS ${v.os}<br/>${final ? 'DOCUMENTO FINAL' : '<span class="pend">DOCUMENTO PRELIMINAR — NÃO VÁLIDO</span>'}</div></header>

  <h2>1. Identificação do veículo e da vistoria</h2><table>${linhasCad}</table>
  <h2>2. Identificadores examinados nas fotografias</h2><table>${linhasCampos}</table>
  <h2>3. Consultas de histórico veicular</h2>
  ${linhasCons ? `<table>${linhasCons}</table>` : '<p class="pend">Nenhuma consulta registrada.</p>'}
  <p class="aviso">Resultado negativo significa apenas que a fonte consultada não retornou registro na data da consulta. Não é garantia de que o veículo nunca tenha sofrido sinistro ou participado de leilão.</p>
  <h2>4. Fotografias</h2>
  ${Object.entries(grupos).map(([cat, figs]) => `<h3 style="font-size:10.5pt;margin:10px 0 4px">${CATEGORIAS[cat]}</h3><div class="grid">${figs.join('')}</div>`).join('') || '<p class="pend">Sem fotografias.</p>'}
  <h2>5. Descrição dos achados visuais</h2>
  <p class="aviso">Descrições preliminares geradas por IA a partir das fotografias e submetidas a revisão humana. A IA não conclui sobre autenticidade de numerações.</p>
  ${achados ? `<ul>${achados}</ul>` : '<p>Sem achados descritos.</p>'}
  <h2>6. Divergências e indícios para análise</h2>
  ${diverg.length ? `<ul>${diverg.map((d) => `<li>${d}</li>`).join('')}</ul>` : '<p>Nenhuma divergência registrada.</p>'}
  <h2>7. Ressalvas e limitações</h2>
  <p>A inspeção baseia-se em fotografias e registros disponíveis na data da emissão. Campos marcados como pendentes ou não identificados não constituem fatos confirmados. ${esc(l.ressalvas || '')}</p>
  <h2>8. Conclusão técnica</h2>
  <p>${l.conclusao ? esc(l.conclusao).replace(/\n/g, '<br/>') : '<span class="pend">Conclusão pendente de redação pelo revisor responsável.</span>'}</p>
  <footer>
  Versão ${l.versao} • Criado em ${dt(l.createdAt)}<br/>
  ${final ? `Aprovado por <b>${esc(revisor?.nome)}</b> em ${dt(l.aprovadoEm!)}<br/>Código de validação: <b>${l.codigoValidacao}</b> — verifique em ${esc(base)}/validar/${l.codigoValidacao}` : 'Documento sem validade até aprovação do revisor responsável.'}
  </footer></body></html>`;

  const browser = await chromium.launch({ args: ['--no-sandbox'] });
  try {
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'load' });
    const pdf = await page.pdf({ format: 'A4', printBackground: true });
    const chave = await salvar(Buffer.from(pdf), 'pdf');
    if (l.pdfChave) await remover(l.pdfChave);
    await prisma.laudo.update({ where: { id: l.id }, data: { pdfChave: chave } });
  } finally { await browser.close(); }
}

// Armazenamento PRIVADO em disco. Para S3/R2, troque salvar/ler mantendo a mesma interface.
import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';

const dir = () => path.resolve(process.env.STORAGE_DIR || './storage');
const RE = /^[a-f0-9-]{36}\.(jpg|pdf|png)$/;

export async function salvar(buf: Buffer, ext: 'jpg' | 'pdf' | 'png') {
  const chave = `${crypto.randomUUID()}.${ext}`;
  await fs.mkdir(dir(), { recursive: true });
  await fs.writeFile(path.join(dir(), chave), buf, { mode: 0o600 });
  return chave;
}
export async function ler(chave: string) {
  if (!RE.test(chave)) throw new Error('chave inválida');
  return fs.readFile(path.join(dir(), chave));
}
export async function remover(chave: string) {
  if (!RE.test(chave)) return;
  await fs.rm(path.join(dir(), chave), { force: true });
}
const seg = () => process.env.FILE_SIGNING_SECRET || '';
const assinar = (chave: string, exp: number) => crypto.createHmac('sha256', seg()).update(`${chave}.${exp}`).digest('hex');
// Link temporário (padrão 1h)
export function urlAssinada(chave: string, ttlSeg = 3600) {
  const exp = Math.floor(Date.now() / 1000) + ttlSeg;
  return `/api/files/${chave}?exp=${exp}&sig=${assinar(chave, exp)}`;
}
export function verificar(chave: string, exp: string | null, sig: string | null) {
  if (!exp || !sig || Number(exp) < Date.now() / 1000) return false;
  const esperado = assinar(chave, Number(exp));
  return sig.length === esperado.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(esperado));
}
export function tipoPorMagia(b: Buffer): 'pdf' | 'jpg' | 'png' | null {
  if (b.subarray(0, 4).toString() === '%PDF') return 'pdf';
  if (b[0] === 0xff && b[1] === 0xd8) return 'jpg';
  if (b[0] === 0x89 && b.subarray(1, 4).toString() === 'PNG') return 'png';
  return null;
}

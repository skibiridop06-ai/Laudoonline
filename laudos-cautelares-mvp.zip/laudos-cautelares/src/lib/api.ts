import { ZodError } from 'zod';
export class HttpError extends Error {
  constructor(public status: number, msg: string) { super(msg); }
}
export function handle<A extends any[]>(fn: (...a: A) => Promise<Response>) {
  return async (...a: A): Promise<Response> => {
    try { return await fn(...a); }
    catch (e: any) {
      if (e instanceof HttpError) return Response.json({ erro: e.message }, { status: e.status });
      if (e instanceof ZodError) return Response.json({ erro: 'Dados inválidos', detalhes: e.flatten().fieldErrors }, { status: 400 });
      console.error(e);
      return Response.json({ erro: 'Erro interno' }, { status: 500 });
    }
  };
}

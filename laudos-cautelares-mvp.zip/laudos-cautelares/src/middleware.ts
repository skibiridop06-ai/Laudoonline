import { NextResponse, type NextRequest } from 'next/server';
import { jwtVerify } from 'jose';

const PUBLICOS = ['/login', '/api/login', '/validar', '/api/files', '/manifest', '/icon'];
export async function middleware(req: NextRequest) {
  const p = req.nextUrl.pathname;
  if (PUBLICOS.some((x) => p.startsWith(x))) return NextResponse.next();
  try {
    const t = req.cookies.get('sess')?.value;
    if (!t) throw new Error('sem sessão');
    await jwtVerify(t, new TextEncoder().encode(process.env.AUTH_SECRET));
    return NextResponse.next();
  } catch {
    if (p.startsWith('/api/')) return NextResponse.json({ erro: 'Não autenticado' }, { status: 401 });
    return NextResponse.redirect(new URL('/login', req.url));
  }
}
export const config = { matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'] };

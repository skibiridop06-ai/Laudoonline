import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';
import { handle } from '@/lib/api';
import { criarSessao } from '@/lib/auth';
import { auditar } from '@/lib/audit';

const falhas = new Map<string, { n: number; ate: number }>();
export const POST = handle(async (req: Request) => {
  const { email, senha } = z.object({ email: z.string().email(), senha: z.string().min(1) }).parse(await req.json());
  const k = email.toLowerCase();
  const f = falhas.get(k);
  if (f && f.n >= 5 && f.ate > Date.now()) return Response.json({ erro: 'Muitas tentativas. Aguarde 15 minutos.' }, { status: 429 });
  const u = await prisma.user.findUnique({ where: { email: k } });
  if (!u || !u.ativo || !(await bcrypt.compare(senha, u.senhaHash))) {
    falhas.set(k, { n: (f && f.ate > Date.now() ? f.n : 0) + 1, ate: Date.now() + 15 * 60_000 });
    return Response.json({ erro: 'E-mail ou senha incorretos.' }, { status: 401 });
  }
  falhas.delete(k);
  await criarSessao(u.id);
  await auditar(u.id, 'LOGIN', 'User', u.id);
  return Response.json({ ok: true });
});

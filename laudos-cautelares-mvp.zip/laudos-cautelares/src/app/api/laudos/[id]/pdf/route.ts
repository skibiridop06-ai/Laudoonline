import { prisma } from '@/lib/db';
import { handle, HttpError } from '@/lib/api';
import { requireUser } from '@/lib/auth';
import { vistoriaDoUsuario } from '@/lib/acesso';
import { ler } from '@/lib/storage';

export const GET = handle(async (_r: Request, { params }: { params: { id: string } }) => {
  const u = await requireUser();
  const l = await prisma.laudo.findUnique({ where: { id: params.id } });
  if (!l || !l.pdfChave) throw new HttpError(404, 'PDF não encontrado');
  await vistoriaDoUsuario(l.vistoriaId, u);
  return new Response(await ler(l.pdfChave), { headers: { 'Content-Type': 'application/pdf', 'Content-Disposition': `inline; filename="${l.numero}-v${l.versao}.pdf"`, 'Cache-Control': 'private, no-store' } });
});

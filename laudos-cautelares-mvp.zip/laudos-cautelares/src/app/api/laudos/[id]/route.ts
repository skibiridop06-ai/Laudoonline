import { z } from 'zod';
import { prisma } from '@/lib/db';
import { handle, HttpError } from '@/lib/api';
import { requireUser } from '@/lib/auth';
import { auditar } from '@/lib/audit';
import { renderizarLaudo } from '@/lib/laudo';
import { faltantes, paraRegra, camposPendentes } from '@/lib/regras';

export const maxDuration = 120;
const corpo = z.discriminatedUnion('acao', [
  z.object({ acao: z.literal('editar'), conclusao: z.string().max(5000), ressalvas: z.string().max(3000).optional() }),
  z.object({ acao: z.literal('enviar_revisao') }),
  z.object({ acao: z.literal('aprovar') }),
  z.object({ acao: z.literal('devolver'), motivo: z.string().min(3).max(1000) }),
]);
export const PATCH = handle(async (req: Request, { params }: { params: { id: string } }) => {
  const d = corpo.parse(await req.json());
  const u = await requireUser(d.acao === 'aprovar' || d.acao === 'devolver' ? ['ADMIN'] : ['SEDE', 'ADMIN']);
  const l = await prisma.laudo.findUnique({ where: { id: params.id } });
  if (!l) throw new HttpError(404, 'Laudo não encontrado');
  const ultima = await prisma.laudo.findFirst({ where: { vistoriaId: l.vistoriaId }, orderBy: { versao: 'desc' } });
  if (ultima!.id !== l.id) throw new HttpError(409, 'Esta não é a versão mais recente.');

  if (d.acao === 'editar') {
    if (l.status !== 'PRELIMINAR') throw new HttpError(409, 'Só é possível editar laudo preliminar.');
    await prisma.laudo.update({ where: { id: l.id }, data: { conclusao: d.conclusao, ressalvas: d.ressalvas ?? null } });
    await renderizarLaudo(l.id);
  }
  if (d.acao === 'enviar_revisao') {
    if (l.status !== 'PRELIMINAR') throw new HttpError(409, 'Laudo não está preliminar.');
    await prisma.laudo.update({ where: { id: l.id }, data: { status: 'EM_REVISAO' } });
    await prisma.vistoria.update({ where: { id: l.vistoriaId }, data: { status: 'EM_REVISAO' } });
  }
  if (d.acao === 'devolver') {
    if (l.status !== 'EM_REVISAO') throw new HttpError(409, 'Laudo não está em revisão.');
    await prisma.laudo.update({ where: { id: l.id }, data: { status: 'DEVOLVIDO', motivoDevolucao: d.motivo, revisorId: u.id } });
    await prisma.vistoria.update({ where: { id: l.vistoriaId }, data: { status: 'DEVOLVIDO' } });
  }
  if (d.acao === 'aprovar') {
    if (l.status !== 'EM_REVISAO') throw new HttpError(409, 'Laudo não está em revisão.');
    const v = await prisma.vistoria.findUniqueOrThrow({ where: { id: l.vistoriaId }, include: { fotos: true, campos: true } });
    const erros: string[] = [];
    const falt = faltantes(v.fotos.map(paraRegra));
    if (falt.length) erros.push(`Fotos obrigatórias ausentes: ${falt.join(', ')}`);
    if (camposPendentes(v.campos).length) erros.push('Há campos extraídos ainda não confirmados pela sede.');
    if (!l.conclusao?.trim()) erros.push('A conclusão técnica não foi redigida.');
    if (erros.length) throw new HttpError(422, erros.join(' | '));
    await prisma.laudo.update({ where: { id: l.id }, data: { status: 'APROVADO', revisorId: u.id, aprovadoEm: new Date() } });
    await prisma.vistoria.update({ where: { id: l.vistoriaId }, data: { status: 'APROVADO' } });
    await renderizarLaudo(l.id); // versão final com selo, revisor e código de validação
  }
  await auditar(u.id, `LAUDO_${d.acao.toUpperCase()}`, 'Laudo', l.id, { versao: l.versao });
  return Response.json({ ok: true });
});

import { z } from 'zod';
import { prisma } from '@/lib/db';
import { handle, HttpError } from '@/lib/api';
import { requireUser } from '@/lib/auth';
import { auditar } from '@/lib/audit';
import { vistoriaDoUsuario } from '@/lib/acesso';
import { remover } from '@/lib/storage';
import { CATEGORIAS } from '@/lib/categorias';
import { enfileirar } from '@/lib/fila';
import { processarFoto, recalcular } from '@/lib/processar';

async function carregar(id: string) {
  const u = await requireUser();
  const f = await prisma.foto.findUnique({ where: { id } });
  if (!f) throw new HttpError(404, 'Foto não encontrada');
  const v = await vistoriaDoUsuario(f.vistoriaId, u);
  if (v.status === 'EM_REVISAO' || v.status === 'APROVADO') throw new HttpError(409, 'Vistoria bloqueada.');
  return { u, f };
}
export const PATCH = handle(async (req: Request, { params }: { params: { id: string } }) => {
  const { u, f } = await carregar(params.id);
  const { categoria } = z.object({ categoria: z.string().refine((c) => c in CATEGORIAS) }).parse(await req.json());
  await prisma.foto.update({ where: { id: f.id }, data: { categoriaConfirmada: categoria } });
  await auditar(u.id, 'CONFIRMAR_CATEGORIA', 'Foto', f.id, { de: f.categoriaSugerida, para: categoria });
  await recalcular(f.vistoriaId);
  return Response.json({ ok: true });
});
export const POST = handle(async (_r: Request, { params }: { params: { id: string } }) => {
  const { u, f } = await carregar(params.id);
  await prisma.foto.update({ where: { id: f.id }, data: { processada: false, erro: null } });
  enfileirar(() => processarFoto(f.id));
  await auditar(u.id, 'REPROCESSAR_FOTO', 'Foto', f.id);
  return Response.json({ ok: true });
});
export const DELETE = handle(async (_r: Request, { params }: { params: { id: string } }) => {
  const { u, f } = await carregar(params.id);
  await prisma.foto.delete({ where: { id: f.id } });
  await remover(f.chave);
  await auditar(u.id, 'EXCLUIR_FOTO', 'Foto', f.id);
  await recalcular(f.vistoriaId);
  return Response.json({ ok: true });
});

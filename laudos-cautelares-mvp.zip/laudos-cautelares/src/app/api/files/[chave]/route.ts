import { ler, verificar } from '@/lib/storage';
export async function GET(req: Request, { params }: { params: { chave: string } }) {
  const u = new URL(req.url);
  if (!verificar(params.chave, u.searchParams.get('exp'), u.searchParams.get('sig'))) return new Response('Link inválido ou expirado', { status: 403 });
  try {
    const b = await ler(params.chave);
    const tipo = params.chave.endsWith('.pdf') ? 'application/pdf' : params.chave.endsWith('.png') ? 'image/png' : 'image/jpeg';
    return new Response(b, { headers: { 'Content-Type': tipo, 'Cache-Control': 'private, max-age=300', 'X-Content-Type-Options': 'nosniff' } });
  } catch { return new Response('Não encontrado', { status: 404 }); }
}

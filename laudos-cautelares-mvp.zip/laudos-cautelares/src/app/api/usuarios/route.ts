import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';
import { handle } from '@/lib/api';
import { requireUser } from '@/lib/auth';
import { auditar } from '@/lib/audit';

const sel = { id: true, nome: true, email: true, role: true, unidade: true, ativo: true };
export const GET = handle(async () => {
  await requireUser(['ADMIN']);
  return Response.json(await prisma.user.findMany({ select: sel, orderBy: { nome: 'asc' } }));
});
export const POST = handle(async (req: Request) => {
  const me = await requireUser(['ADMIN']);
  const d = z.object({ nome: z.string().min(2), email: z.string().email(), senha: z.string().min(10, 'Mínimo 10 caracteres'), role: z.enum(['PERITO', 'SEDE', 'ADMIN']), unidade: z.string().optional() }).parse(await req.json());
  const u = await prisma.user.create({ data: { nome: d.nome, email: d.email.toLowerCase(), senhaHash: await bcrypt.hash(d.senha, 12), role: d.role, unidade: d.unidade }, select: sel });
  await auditar(me.id, 'CRIAR_USUARIO', 'User', u.id, { role: d.role });
  return Response.json(u);
});
export const PATCH = handle(async (req: Request) => {
  const me = await requireUser(['ADMIN']);
  const d = z.object({ id: z.string(), ativo: z.boolean() }).parse(await req.json());
  if (d.id === me.id) return Response.json({ erro: 'Você não pode desativar a si mesmo.' }, { status: 400 });
  const u = await prisma.user.update({ where: { id: d.id }, data: { ativo: d.ativo }, select: sel });
  await auditar(me.id, d.ativo ? 'ATIVAR_USUARIO' : 'DESATIVAR_USUARIO', 'User', u.id);
  return Response.json(u);
});

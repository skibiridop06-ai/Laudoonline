import { encerrarSessao } from '@/lib/auth';
export async function POST() { encerrarSessao(); return Response.json({ ok: true }); }

import { z } from 'zod';
import { prisma } from '@/lib/db';
import { handle, HttpError } from '@/lib/api';
import { requireUser } from '@/lib/auth';
import { auditar } from '@/lib/audit';
import { vistoriaDoUsuario } from '@/lib/acesso';
import { salvar, tipoPorMagia } from '@/lib/storage';
import { CONSULTA_TIPOS, CONSULTA_RESULTADOS } from '@/lib/categorias';

// Importação manual de resultado de consulta externa. NÃO existe consulta simulada.
export const POST = handle(async (req: Request, { params }: { params: { id: string } }) => {
  const u = await requireUser(['SEDE', 'ADMIN']);
  const v = await vistoriaDoUsuario(params.id, u);
  const fd = await req.formData();
  const d = z.object({
    tipo: z.string().refine((x) => x in CONSULTA_TIPOS), fonte: z.string().min(2).max(120),
    dataConsulta: z.string().refine((s) => !isNaN(Date.parse(s)), 'Data inválida'),
    resultado: z.string().refine((x) => x in CONSULTA_RESULTADOS), detalhes: z.string().max(2000).optional(),
  }).parse({ tipo: fd.get('tipo'), fonte: fd.get('fonte'), dataConsulta: fd.get('dataConsulta'), resultado: fd.get('resultado'), detalhes: fd.get('detalhes') || undefined });
  let comprovanteChave: string | null = null;
  const arq = fd.get('comprovante');
  if (arq instanceof File && arq.size > 0) {
    if (arq.size > 15 * 1024 * 1024) throw new HttpError(400, 'Comprovante maior que 15 MB.');
    const buf = Buffer.from(await arq.arrayBuffer());
    const t = tipoPorMagia(buf);
    if (!t) throw new HttpError(400, 'Comprovante deve ser PDF, JPG ou PNG.');
    comprovanteChave = await salvar(buf, t);
  }
  if ((d.resultado === 'POSITIVO' || d.resultado === 'NEGATIVO') && !comprovanteChave) throw new HttpError(400, 'Anexe o comprovante para resultado positivo ou negativo.');
  const c = await prisma.consulta.create({ data: { vistoriaId: v.id, ...d, dataConsulta: new Date(d.dataConsulta), comprovanteChave, userId: u.id } });
  await auditar(u.id, 'REGISTRAR_CONSULTA', 'Consulta', c.id, { tipo: d.tipo, resultado: d.resultado, fonte: d.fonte });
  return Response.json({ ok: true });
});

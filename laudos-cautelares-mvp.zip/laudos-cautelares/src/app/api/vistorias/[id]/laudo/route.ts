import crypto from 'crypto';
import { prisma } from '@/lib/db';
import { handle, HttpError } from '@/lib/api';
import { requireUser } from '@/lib/auth';
import { auditar } from '@/lib/audit';
import { vistoriaDoUsuario } from '@/lib/acesso';
import { renderizarLaudo } from '@/lib/laudo';

export const maxDuration = 120;
// Gera uma NOVA versão preliminar do laudo (mantém as anteriores para histórico).
export const POST = handle(async (_r: Request, { params }: { params: { id: string } }) => {
  const u = await requireUser(['SEDE', 'ADMIN']);
  const v = await vistoriaDoUsuario(params.id, u);
  if (v.status === 'APROVADO') throw new HttpError(409, 'Vistoria já aprovada.');
  const ult = await prisma.laudo.findFirst({ where: { vistoriaId: v.id }, orderBy: { versao: 'desc' } });
  const numero = ult?.numero ?? `LC-${new Date().getFullYear()}-${String(v.os).padStart(6, '0')}`;
  const l = await prisma.laudo.create({ data: {
    vistoriaId: v.id, numero, versao: (ult?.versao ?? 0) + 1, codigoValidacao: crypto.randomBytes(8).toString('hex').toUpperCase(),
    criadoPorId: u.id, conclusao: ult?.conclusao ?? null, ressalvas: ult?.ressalvas ?? null } });
  await renderizarLaudo(l.id);
  await prisma.vistoria.update({ where: { id: v.id }, data: { status: v.status === 'DEVOLVIDO' ? 'EM_CONFERENCIA' : v.status } });
  await auditar(u.id, 'GERAR_LAUDO', 'Laudo', l.id, { versao: l.versao });
  return Response.json({ id: l.id, versao: l.versao });
});

import crypto from 'crypto';
import sharp from 'sharp';
import { prisma } from '@/lib/db';
import { handle, HttpError } from '@/lib/api';
import { requireUser } from '@/lib/auth';
import { auditar } from '@/lib/audit';
import { vistoriaDoUsuario } from '@/lib/acesso';
import { salvar } from '@/lib/storage';
import { enfileirar } from '@/lib/fila';
import { processarFoto } from '@/lib/processar';

export const maxDuration = 120;
export const POST = handle(async (req: Request, { params }: { params: { id: string } }) => {
  const u = await requireUser();
  const v = await vistoriaDoUsuario(params.id, u);
  if (v.status === 'EM_REVISAO' || v.status === 'APROVADO') throw new HttpError(409, 'Vistoria bloqueada para novas fotos.');
  const files = (await req.formData()).getAll('fotos').filter((f): f is File => f instanceof File);
  if (!files.length) throw new HttpError(400, 'Nenhuma foto enviada.');
  if (files.length > 40) throw new HttpError(400, 'Máximo de 40 fotos por envio.');
  const criadas: string[] = [], rejeitadas: string[] = [];
  const existentes = await prisma.foto.findMany({ where: { vistoriaId: v.id }, select: { id: true, sha256: true } });
  const vistos = new Map(existentes.map((e) => [e.sha256, e.id]));
  for (const file of files) {
    try {
      if (file.size > 20 * 1024 * 1024) throw new Error('maior que 20 MB');
      // sharp valida que é imagem de verdade e re-codifica (remove payloads embutidos); orienta e limita a 2000px.
      const buf = await sharp(Buffer.from(await file.arrayBuffer())).rotate().resize({ width: 2000, height: 2000, fit: 'inside', withoutEnlargement: true }).jpeg({ quality: 85 }).toBuffer();
      const sha = crypto.createHash('sha256').update(buf).digest('hex');
      const dup = vistos.get(sha);
      const chave = await salvar(buf, 'jpg');
      const f = await prisma.foto.create({ data: { vistoriaId: v.id, chave, sha256: sha, duplicadaDe: dup ?? null, processada: !!dup, erro: dup ? 'Foto duplicada.' : null } });
      vistos.set(sha, dup ?? f.id);
      criadas.push(f.id);
      if (!dup) enfileirar(() => processarFoto(f.id));
    } catch { rejeitadas.push(file.name); }
  }
  if (criadas.length) await prisma.vistoria.update({ where: { id: v.id }, data: { status: 'EM_ANALISE' } });
  await auditar(u.id, 'UPLOAD_FOTOS', 'Vistoria', v.id, { enviadas: criadas.length, rejeitadas });
  return Response.json({ criadas: criadas.length, rejeitadas });
});

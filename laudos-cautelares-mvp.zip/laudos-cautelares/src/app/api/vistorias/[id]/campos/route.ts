import { z } from 'zod';
import { prisma } from '@/lib/db';
import { handle } from '@/lib/api';
import { requireUser } from '@/lib/auth';
import { auditar } from '@/lib/audit';
import { vistoriaDoUsuario } from '@/lib/acesso';
import { CAMPOS } from '@/lib/categorias';

// Sede/Admin confirma ou corrige um campo. Inserção humana = CONFIRMADO, origem HUMANO.
export const PUT = handle(async (req: Request, { params }: { params: { id: string } }) => {
  const u = await requireUser(['SEDE', 'ADMIN']);
  const v = await vistoriaDoUsuario(params.id, u);
  const d = z.object({ chave: z.string().refine((c) => c in CAMPOS || c === 'divergencia_placa'), valor: z.string().max(120).nullable() }).parse(await req.json());
  const valor = d.valor?.trim() || null;
  const antes = await prisma.campo.findUnique({ where: { vistoriaId_chave: { vistoriaId: v.id, chave: d.chave } } });
  const dados = { valor, confianca: 1, status: valor ? 'CONFIRMADO' : 'NAO_IDENTIFICADO', origem: 'HUMANO', fotoId: antes?.fotoId ?? null };
  await prisma.campo.upsert({ where: { vistoriaId_chave: { vistoriaId: v.id, chave: d.chave } }, update: dados, create: { vistoriaId: v.id, chave: d.chave, ...dados } });
  await auditar(u.id, 'CONFIRMAR_CAMPO', 'Campo', `${v.id}:${d.chave}`, { antes: antes?.valor ?? null, depois: valor });
  return Response.json({ ok: true });
});

import { z } from 'zod';
import { prisma } from '@/lib/db';
import { handle } from '@/lib/api';
import { requireUser } from '@/lib/auth';
import { auditar } from '@/lib/audit';
import { vistoriaDoUsuario } from '@/lib/acesso';
import { urlAssinada } from '@/lib/storage';
import { faltantes, paraRegra, camposPendentes } from '@/lib/regras';

export const GET = handle(async (_r: Request, { params }: { params: { id: string } }) => {
  const u = await requireUser();
  await vistoriaDoUsuario(params.id, u);
  const v = await prisma.vistoria.findUniqueOrThrow({ where: { id: params.id }, include: {
    perito: { select: { nome: true } }, fotos: { orderBy: { createdAt: 'asc' } }, campos: true,
    consultas: { orderBy: { dataConsulta: 'desc' } }, laudos: { orderBy: { versao: 'desc' } } } });
  const { fotos, consultas, campos, laudos, ...vistoria } = v;
  return Response.json({
    me: { id: u.id, nome: u.nome, role: u.role }, vistoria,
    fotos: fotos.map((f) => ({ ...f, chave: undefined, url: urlAssinada(f.chave) })),
    campos, laudos: laudos.map((l) => ({ ...l, pdfChave: undefined })),
    consultas: consultas.map((c) => ({ ...c, comprovanteChave: undefined, comprovanteUrl: c.comprovanteChave ? urlAssinada(c.comprovanteChave) : null })),
    faltantes: faltantes(fotos.map(paraRegra)),
    pendentesCampos: camposPendentes(campos).map((c) => c.chave),
  });
});

export const PATCH = handle(async (req: Request, { params }: { params: { id: string } }) => {
  const u = await requireUser(['SEDE', 'ADMIN']);
  await vistoriaDoUsuario(params.id, u);
  const d = z.object({
    observacaoSede: z.string().max(1000).nullable().optional(), marca: z.string().max(60).optional(), modelo: z.string().max(80).optional(),
    cor: z.string().max(40).optional(), cliente: z.string().max(120).optional(), local: z.string().max(160).optional(),
  }).parse(await req.json());
  const v = await prisma.vistoria.update({ where: { id: params.id }, data: d });
  await auditar(u.id, 'EDITAR_VISTORIA', 'Vistoria', v.id, d);
  return Response.json(v);
});

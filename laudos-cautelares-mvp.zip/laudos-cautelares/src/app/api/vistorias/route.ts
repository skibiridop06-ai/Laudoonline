import { z } from 'zod';
import { prisma } from '@/lib/db';
import { handle } from '@/lib/api';
import { requireUser } from '@/lib/auth';
import { auditar } from '@/lib/audit';
import { normalizaPlaca, placaValida } from '@/lib/regras';

const esquema = z.object({
  placa: z.string().refine(placaValida, 'Placa inválida (ex.: ABC1D23)'),
  marca: z.string().max(60).optional(), modelo: z.string().max(80).optional(),
  anoFab: z.coerce.number().int().min(1950).max(2100).optional().or(z.literal('').transform(() => undefined)),
  anoModelo: z.coerce.number().int().min(1950).max(2100).optional().or(z.literal('').transform(() => undefined)),
  cor: z.string().max(40).optional(), cliente: z.string().max(120).optional(), local: z.string().max(160).optional(),
  peritoId: z.string().optional(),
});
export const POST = handle(async (req: Request) => {
  const u = await requireUser();
  const d = esquema.parse(await req.json());
  const peritoId = u.role === 'PERITO' ? u.id : d.peritoId || u.id;
  const { peritoId: _p, ...resto } = d;
  const v = await prisma.vistoria.create({ data: { ...resto, placa: normalizaPlaca(d.placa), peritoId } });
  await auditar(u.id, 'CRIAR_VISTORIA', 'Vistoria', v.id, { placa: v.placa });
  return Response.json(v);
});

'use client';
import { useState } from 'react';

export default function Login() {
  const [erro, setErro] = useState('');
  const [busy, setBusy] = useState(false);
  async function enviar(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setErro('');
    const fd = new FormData(e.currentTarget);
    const r = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: fd.get('email'), senha: fd.get('senha') }) });
    if (r.ok) { location.href = '/painel'; return; }
    setErro((await r.json().catch(() => ({}))).erro || 'Não foi possível entrar.'); setBusy(false);
  }
  return (
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center p-6">
      <h1 className="mb-1 text-2xl font-bold text-petrol">Laudos Cautelares</h1>
      <p className="mb-6 text-sm text-ink/70">Entre com seu e-mail e senha.</p>
      <form onSubmit={enviar} className="card space-y-4">
        <div><label className="lbl" htmlFor="email">E-mail</label><input id="email" name="email" type="email" required autoComplete="username" className="inp" /></div>
        <div><label className="lbl" htmlFor="senha">Senha</label><input id="senha" name="senha" type="password" required autoComplete="current-password" className="inp" /></div>
        {erro && <p role="alert" className="text-sm font-medium text-bad">{erro}</p>}
        <button className="btn w-full" disabled={busy}>{busy ? 'Entrando…' : 'Entrar'}</button>
      </form>
    </main>
  );
}

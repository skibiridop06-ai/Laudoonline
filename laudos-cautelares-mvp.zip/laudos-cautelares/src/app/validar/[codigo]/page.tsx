import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';
export default async function Validar({ params }: { params: { codigo: string } }) {
  const l = await prisma.laudo.findUnique({ where: { codigoValidacao: params.codigo.toUpperCase() }, include: { vistoria: { select: { placa: true } } } });
  const valido = l && l.status === 'APROVADO';
  return (
    <main className="mx-auto max-w-md p-6">
      <h1 className="mb-4 text-xl font-bold text-petrol">Validação de laudo</h1>
      <div className={`card ${valido ? 'border-ok' : 'border-bad'}`}>
        {valido ? (
          <>
            <p className="font-semibold text-ok">Laudo autêntico e aprovado.</p>
            <p className="mt-2 text-sm">Nº {l!.numero} · versão {l!.versao}</p>
            <p className="text-sm">Placa: {l!.vistoria.placa.slice(0, 3)}****</p>
            <p className="text-sm">Aprovado em {l!.aprovadoEm!.toLocaleDateString('pt-BR')}</p>
            <p className="mt-2 text-xs text-ink/60">Confira se o código impresso no documento é idêntico a este: {l!.codigoValidacao}</p>
          </>
        ) : <p className="font-semibold text-bad">Código não encontrado ou laudo não aprovado.</p>}
      </div>
    </main>
  );
}

import { redirect } from 'next/navigation';
import { getUser } from '@/lib/auth';
import Usuarios from './Usuarios';
export default async function Page() { const u = await getUser(); if (u?.role !== 'ADMIN') redirect('/painel'); return <Usuarios />; }

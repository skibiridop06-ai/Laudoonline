'use client';
import { useEffect, useState } from 'react';

export default function Usuarios() {
  const [lista, setLista] = useState<any[]>([]);
  const [erro, setErro] = useState('');
  const load = async () => setLista(await (await fetch('/api/usuarios')).json());
  useEffect(() => { load(); }, []);
  async function criar(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setErro('');
    const form = e.currentTarget;
    const r = await fetch('/api/usuarios', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(new FormData(form))) });
    const j = await r.json();
    if (r.ok) { form.reset(); load(); } else setErro(j.detalhes?.senha?.[0] || j.detalhes?.email?.[0] || j.erro || 'Erro');
  }
  async function alternar(u: any) {
    const r = await fetch('/api/usuarios', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: u.id, ativo: !u.ativo }) });
    if (!r.ok) setErro((await r.json()).erro); else load();
  }
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold">Usuários</h1>
      <form onSubmit={criar} className="card grid gap-2 md:grid-cols-5">
        <input name="nome" required placeholder="Nome" className="inp" /><input name="email" type="email" required placeholder="E-mail" className="inp" />
        <input name="senha" type="password" required minLength={10} placeholder="Senha (mín. 10)" className="inp" />
        <select name="role" className="inp"><option value="PERITO">Perito</option><option value="SEDE">Sede</option><option value="ADMIN">Administrador</option></select>
        <button className="btn">Cadastrar</button>
        {erro && <p role="alert" className="text-sm font-medium text-bad md:col-span-5">{erro}</p>}
      </form>
      <div className="card overflow-x-auto p-0"><table className="w-full min-w-[520px]"><thead><tr><th>Nome</th><th>E-mail</th><th>Perfil</th><th>Situação</th><th></th></tr></thead>
        <tbody>{lista.map((u) => <tr key={u.id}><td>{u.nome}</td><td>{u.email}</td><td>{u.role}</td><td>{u.ativo ? 'Ativo' : 'Inativo'}</td><td><button className="underline" onClick={() => alternar(u)}>{u.ativo ? 'Desativar' : 'Ativar'}</button></td></tr>)}</tbody></table></div>
    </div>
  );
}

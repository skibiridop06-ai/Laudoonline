import { prisma } from '@/lib/db';
import { getUser } from '@/lib/auth';

export default async function Painel({ searchParams }: { searchParams: { de?: string; ate?: string; peritoId?: string } }) {
  const u = (await getUser())!;
  const where: any = u.role === 'PERITO' ? { peritoId: u.id } : searchParams.peritoId ? { peritoId: searchParams.peritoId } : {};
  if (searchParams.de || searchParams.ate) where.createdAt = { ...(searchParams.de && { gte: new Date(searchParams.de) }), ...(searchParams.ate && { lte: new Date(searchParams.ate + 'T23:59:59') }) };
  const [vs, peritos] = await Promise.all([
    prisma.vistoria.findMany({ where, include: { consultas: { select: { id: true } }, perito: { select: { nome: true } }, laudos: { select: { status: true, aprovadoEm: true } } } }),
    u.role === 'PERITO' ? [] : prisma.user.findMany({ where: { role: 'PERITO' }, select: { id: true, nome: true } }),
  ]);
  const inicioHoje = new Date(); inicioHoje.setHours(0, 0, 0, 0);
  const n = (s: string) => vs.filter((v) => v.status === s).length;
  const aprov = vs.flatMap((v) => v.laudos.filter((l) => l.aprovadoEm).map((l) => ({ v, t: l.aprovadoEm!.getTime() - v.createdAt.getTime(), d: l.aprovadoEm! })));
  const horas = aprov.length ? aprov.reduce((a, x) => a + x.t, 0) / aprov.length / 3.6e6 : null;
  const cards: [string, number | string][] = [
    ['Recebidas hoje', vs.filter((v) => v.createdAt >= inicioHoje).length], ['Aguardando análise', n('EM_ANALISE')],
    ['Fotos pendentes', n('FOTOS_PENDENTES')], ['Consultas não realizadas', vs.filter((v) => !v.consultas.length && v.status !== 'APROVADO').length],
    ['Em revisão', n('EM_REVISAO')], ['Aprovados', n('APROVADO')], ['Devolvidos', n('DEVOLVIDO')],
    ['Tempo médio até emissão', horas === null ? '—' : horas < 48 ? `${horas.toFixed(1).replace('.', ',')} h` : `${(horas / 24).toFixed(1).replace('.', ',')} dias`],
  ];
  const porPerito = Object.entries(vs.reduce<Record<string, number>>((a, v) => ((a[v.perito.nome] = (a[v.perito.nome] || 0) + 1), a), {})).sort((a, b) => b[1] - a[1]);
  const dias = Array.from({ length: 14 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - (13 - i)); return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }); });
  const prod = dias.map((d) => aprov.filter((a) => a.d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) === d).length);
  const max = Math.max(1, ...prod);
  return (
    <div className="space-y-5">
      <h1 className="text-xl font-bold">Painel</h1>
      <form className="card flex flex-wrap items-end gap-3">
        <div><label className="lbl">De</label><input type="date" name="de" defaultValue={searchParams.de} className="inp" /></div>
        <div><label className="lbl">Até</label><input type="date" name="ate" defaultValue={searchParams.ate} className="inp" /></div>
        {u.role !== 'PERITO' && <div><label className="lbl">Perito</label><select name="peritoId" defaultValue={searchParams.peritoId || ''} className="inp"><option value="">Todos</option>{peritos.map((p) => <option key={p.id} value={p.id}>{p.nome}</option>)}</select></div>}
        <button className="btn">Filtrar</button>
      </form>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map(([t, x]) => <div key={t} className="card"><div className="text-2xl font-bold text-petrol">{x}</div><div className="text-sm text-ink/70">{t}</div></div>)}
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="card"><h2 className="mb-2 font-semibold">Vistorias por perito</h2>
          {porPerito.length ? <table className="w-full"><tbody>{porPerito.map(([nome, q]) => <tr key={nome}><td>{nome}</td><td className="text-right font-semibold">{q}</td></tr>)}</tbody></table> : <p className="text-sm text-ink/60">Sem vistorias no período.</p>}
        </div>
        <div className="card"><h2 className="mb-2 font-semibold">Laudos aprovados — últimos 14 dias</h2>
          <div className="flex h-32 items-end gap-1">{prod.map((q, i) => <div key={i} className="flex flex-1 flex-col items-center justify-end"><span className="text-[10px]">{q || ''}</span><div className="w-full rounded-t bg-petrol" style={{ height: `${(q / max) * 100}%`, minHeight: q ? 4 : 1 }} /></div>)}</div>
          <div className="mt-1 flex justify-between text-[10px] text-ink/60"><span>{dias[0]}</span><span>{dias[13]}</span></div>
        </div>
      </div>
    </div>
  );
}

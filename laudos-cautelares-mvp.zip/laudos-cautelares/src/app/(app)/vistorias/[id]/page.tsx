import Detalhe from './Detalhe';
export default function Page({ params }: { params: { id: string } }) { return <Detalhe id={params.id} />; }

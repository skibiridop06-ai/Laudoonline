'use client';
import { useCallback, useEffect, useState } from 'react';
import { CATEGORIAS, CAMPOS, CONSULTA_TIPOS, CONSULTA_RESULTADOS, STATUS_VISTORIA, STATUS_LAUDO, STATUS_CAMPO } from '@/lib/categorias';
import { Badge } from '@/components/ui';

const JSON_H = { 'Content-Type': 'application/json' };

export default function Detalhe({ id }: { id: string }) {
  const [d, setD] = useState<any>(null);
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [zoom, setZoom] = useState<string | null>(null);
  const [ampliado, setAmpliado] = useState(false);
  const [vals, setVals] = useState<Record<string, string>>({});
  const [conclusao, setConclusao] = useState<string | null>(null);
  const [ressalvas, setRessalvas] = useState<string | null>(null);
  const [obs, setObs] = useState<string | null>(null);

  const load = useCallback(async () => { const r = await fetch(`/api/vistorias/${id}`); if (r.ok) setD(await r.json()); }, [id]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    if (!d?.fotos.some((f: any) => !f.processada)) return;
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, [d, load]);

  async function call(url: string, method: string, body?: any, ok = 'Salvo.') {
    setBusy(true); setMsg(null);
    const isFd = body instanceof FormData;
    const r = await fetch(url, { method, headers: body && !isFd ? JSON_H : undefined, body: body ? (isFd ? body : JSON.stringify(body)) : undefined });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    setMsg({ ok: r.ok, t: r.ok ? ok : j.erro || 'Não foi possível concluir.' });
    if (r.ok) await load();
    return r.ok;
  }
  if (!d) return <p>Carregando…</p>;

  const role = d.me.role, sede = role !== 'PERITO', admin = role === 'ADMIN';
  const v = d.vistoria, travado = v.status === 'EM_REVISAO' || v.status === 'APROVADO';
  const ult = d.laudos[0];
  const ilegiveis = d.fotos.filter((f: any) => f.processada && f.legivel === false && !f.categoriaConfirmada && !f.duplicadaDe);
  const duplicadas = d.fotos.filter((f: any) => f.duplicadaDe);
  const analisando = d.fotos.filter((f: any) => !f.processada).length;

  async function enviar(files: FileList | null) {
    if (!files?.length) return;
    const fd = new FormData();
    Array.from(files).forEach((f) => fd.append('fotos', f));
    await call(`/api/vistorias/${id}/fotos`, 'POST', fd, 'Fotos enviadas. A análise automática começou.');
  }
  async function novaConsulta(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    if (await call(`/api/vistorias/${id}/consultas`, 'POST', new FormData(form), 'Consulta registrada.')) form.reset();
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-xl font-bold">OS {v.os} · {v.placa}</h1>
        <Badge k={v.status}>{STATUS_VISTORIA[v.status]}</Badge>
        {v.demo && <span className="text-xs font-semibold text-warn">[DADOS FICTÍCIOS DE DEMONSTRAÇÃO]</span>}
      </div>
      <p className="text-sm text-ink/70">{[v.marca, v.modelo, v.cor].filter(Boolean).join(' · ') || 'Sem dados do veículo'} · Perito: {v.perito.nome}{v.cliente ? ` · Cliente: ${v.cliente}` : ''}</p>
      {msg && <p role="status" className={`rounded border px-3 py-2 text-sm font-medium ${msg.ok ? 'border-green-300 bg-green-50 text-ok' : 'border-red-300 bg-red-50 text-bad'}`}>{msg.t}</p>}

      {/* Pendências */}
      <section className="card space-y-2">
        <h2 className="font-semibold">Pendências</h2>
        {analisando > 0 && <p className="text-sm">Analisando {analisando} foto(s)…</p>}
        {v.observacaoSede && <p className="rounded bg-amber-50 p-2 text-sm"><b>Solicitação da sede:</b> {v.observacaoSede}</p>}
        {d.faltantes.length > 0 ? (
          <div><p className="text-sm font-medium text-warn">Faltam fotos obrigatórias legíveis:</p>
            <ul className="list-inside list-disc text-sm">{d.faltantes.map((c: string) => <li key={c}>{CATEGORIAS[c]}</li>)}</ul></div>
        ) : <p className="text-sm text-ok">Todas as fotos obrigatórias foram enviadas.</p>}
        {ilegiveis.length > 0 && <p className="text-sm text-warn">{ilegiveis.length} foto(s) ilegível(is) ou de baixa qualidade — refaça ou reenvie.</p>}
        {duplicadas.length > 0 && <p className="text-sm text-ink/70">{duplicadas.length} foto(s) duplicada(s) ignorada(s).</p>}
        {sede && !travado && (
          <div className="flex flex-col gap-2 pt-1 sm:flex-row">
            <input className="inp" placeholder="Solicitar novas fotos ao perito (mensagem)" value={obs ?? v.observacaoSede ?? ''} onChange={(e) => setObs(e.target.value)} />
            <button className="btn-sec" disabled={busy} onClick={() => call(`/api/vistorias/${id}`, 'PATCH', { observacaoSede: (obs ?? v.observacaoSede ?? '') || null }, 'Mensagem enviada ao perito.')}>Enviar</button>
          </div>
        )}
      </section>

      {/* Fotos */}
      <section className="card space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-semibold">Fotografias ({d.fotos.length})</h2>
          {!travado && (
            <div className="flex gap-2">
              <label className="btn cursor-pointer">Tirar foto<input type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => { enviar(e.target.files); e.target.value = ''; }} /></label>
              <label className="btn-sec cursor-pointer">Enviar da galeria<input type="file" accept="image/*" multiple className="hidden" onChange={(e) => { enviar(e.target.files); e.target.value = ''; }} /></label>
            </div>
          )}
        </div>
        {busy && <p className="text-sm">Enviando…</p>}
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
          {d.fotos.map((f: any) => {
            const cat = f.categoriaConfirmada ?? f.categoriaSugerida ?? '';
            return (
              <div key={f.id} className="overflow-hidden rounded border border-line bg-white text-xs">
                <button className="block w-full" onClick={() => { setZoom(f.url); setAmpliado(false); }} aria-label="Ampliar foto"><img src={f.url} alt={cat ? CATEGORIAS[cat] : 'Foto'} loading="lazy" className="aspect-[4/3] w-full object-cover" /></button>
                <div className="space-y-1 p-2">
                  {!f.processada ? <span className="text-ink/60">Analisando…</span> : f.duplicadaDe ? <span className="font-semibold text-warn">Duplicada</span> : f.erro ? <span className="text-warn">{f.erro}</span> : (
                    <>
                      <div>{f.categoriaConfirmada ? <Badge k="CONFIRMADO">Confirmada</Badge> : <Badge k="IDENTIFICADO">Sugerida {Math.round((f.confCategoria ?? 0) * 100)}%</Badge>}</div>
                      {f.legivel === false && <div className="font-semibold text-bad">Ilegível / baixa qualidade</div>}
                      <div className="text-ink/60">Nitidez {f.nitidez} · Luz {f.iluminacao} · Enquadr. {f.enquadramento}</div>
                      {f.descricao && <div>{f.descricao}</div>}
                      {f.indicios && <div className="text-warn">Indício (análise humana): {f.indicios}</div>}
                    </>
                  )}
                  {!travado && (
                    <select className="inp !py-1 text-xs" value={cat} onChange={(e) => call(`/api/fotos/${f.id}`, 'PATCH', { categoria: e.target.value }, 'Categoria confirmada.')}>
                      <option value="">Definir categoria…</option>{Object.entries(CATEGORIAS).map(([k, t]) => <option key={k} value={k}>{t}</option>)}
                    </select>
                  )}
                  {!travado && (
                    <div className="flex gap-2">
                      {sede && <button className="underline" onClick={() => call(`/api/fotos/${f.id}`, 'POST', undefined, 'Reprocessando…')}>Reanalisar</button>}
                      <button className="text-bad underline" onClick={() => confirm('Excluir esta foto?') && call(`/api/fotos/${f.id}`, 'DELETE', undefined, 'Foto excluída.')}>Excluir</button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        {!d.fotos.length && <p className="text-sm text-ink/60">Nenhuma foto ainda. Use “Tirar foto” ou envie várias de uma vez da galeria.</p>}
      </section>

      {/* Dados extraídos */}
      {sede && (
        <section className="card space-y-2">
          <h2 className="font-semibold">Dados extraídos — conferência</h2>
          <p className="text-sm text-ink/70">A IA nunca completa caracteres ilegíveis. Só entram no laudo como fato os campos confirmados aqui.</p>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px]">
              <thead><tr><th>Campo</th><th>Valor</th><th>Situação</th><th>Origem</th><th></th></tr></thead>
              <tbody>
                {[...Object.keys(CAMPOS), ...(d.campos.some((c: any) => c.chave === 'divergencia_placa') ? ['divergencia_placa'] : [])].map((k) => {
                  const c = d.campos.find((x: any) => x.chave === k);
                  const st = c?.status ?? 'NAO_IDENTIFICADO';
                  return (
                    <tr key={k}>
                      <td>{k === 'divergencia_placa' ? 'Divergência: placa da foto × cadastro' : CAMPOS[k]}</td>
                      <td><input className="inp !py-1" disabled={travado || k === 'divergencia_placa'} value={vals[k] ?? c?.valor ?? ''} onChange={(e) => setVals({ ...vals, [k]: e.target.value })} placeholder="não identificado" /></td>
                      <td><Badge k={st}>{STATUS_CAMPO[st]}</Badge>{c && c.origem === 'FOTO' && c.confianca > 0 && <span className="ml-1 text-xs text-ink/60">{Math.round(c.confianca * 100)}%</span>}</td>
                      <td>{c ? ({ FOTO: 'Fotografia', HUMANO: 'Humano' } as any)[c.origem] : '—'}</td>
                      <td>{!travado && <button className="btn-sec !py-1" disabled={busy} onClick={() => call(`/api/vistorias/${id}/campos`, 'PUT', { chave: k, valor: k === 'divergencia_placa' ? c?.valor ?? null : (vals[k] ?? c?.valor ?? '') || null }, 'Campo confirmado.')}>{k === 'divergencia_placa' ? 'Marcar como conferida' : 'Confirmar'}</button>}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Consultas */}
      {sede && (
        <section className="card space-y-3">
          <h2 className="font-semibold">Consultas veiculares</h2>
          <p className="text-sm text-ink/70">Nenhuma consulta é simulada: registre aqui o resultado obtido em fonte autorizada e anexe o comprovante.</p>
          <ul className="space-y-2">
            {d.consultas.map((c: any) => (
              <li key={c.id} className="rounded border border-line p-2 text-sm">
                <b>{CONSULTA_TIPOS[c.tipo]}</b> — <Badge k={c.resultado}>{CONSULTA_RESULTADOS[c.resultado]}</Badge><br />
                Fonte: {c.fonte} · {new Date(c.dataConsulta).toLocaleDateString('pt-BR')}{c.detalhes ? ` · ${c.detalhes}` : ''}
                {c.comprovanteUrl && <> · <a className="text-petrol underline" href={c.comprovanteUrl} target="_blank">Comprovante</a></>}
              </li>
            ))}
            {!d.consultas.length && <li className="text-sm text-warn">Nenhuma consulta registrada.</li>}
          </ul>
          {!travado && (
            <form onSubmit={novaConsulta} className="grid gap-2 md:grid-cols-2">
              <select name="tipo" required className="inp">{Object.entries(CONSULTA_TIPOS).map(([k, t]) => <option key={k} value={k}>{t}</option>)}</select>
              <select name="resultado" required className="inp">{Object.entries(CONSULTA_RESULTADOS).map(([k, t]) => <option key={k} value={k}>{t}</option>)}</select>
              <input name="fonte" required className="inp" placeholder="Fonte (ex.: fornecedor/órgão consultado)" />
              <input name="dataConsulta" type="date" required className="inp" />
              <textarea name="detalhes" className="inp md:col-span-2" placeholder="Detalhes do resultado (opcional)" />
              <div className="md:col-span-2"><label className="lbl">Comprovante (PDF/JPG/PNG) — obrigatório p/ positivo e negativo</label><input name="comprovante" type="file" accept="application/pdf,image/*" className="inp" /></div>
              <button className="btn md:col-span-2" disabled={busy}>Registrar consulta</button>
            </form>
          )}
        </section>
      )}

      {/* Laudo */}
      <section className="card space-y-3">
        <h2 className="font-semibold">Laudo</h2>
        {sede && v.status !== 'APROVADO' && <button className="btn" disabled={busy} onClick={() => call(`/api/vistorias/${id}/laudo`, 'POST', undefined, 'Nova versão preliminar gerada.')}>{busy ? 'Gerando PDF…' : 'Gerar laudo preliminar (nova versão)'}</button>}
        {ult && (
          <div className="space-y-2">
            {ult.status === 'DEVOLVIDO' && <p className="rounded bg-red-50 p-2 text-sm text-bad"><b>Devolvido:</b> {ult.motivoDevolucao}. Corrija e gere uma nova versão.</p>}
            {ult.status === 'PRELIMINAR' && sede && (
              <div className="space-y-2">
                <label className="lbl">Conclusão técnica (redigida pelo responsável — a IA não conclui)</label>
                <textarea className="inp min-h-28" value={conclusao ?? ult.conclusao ?? ''} onChange={(e) => setConclusao(e.target.value)} />
                <label className="lbl">Ressalvas adicionais (opcional)</label>
                <textarea className="inp" value={ressalvas ?? ult.ressalvas ?? ''} onChange={(e) => setRessalvas(e.target.value)} />
                <div className="flex flex-wrap gap-2">
                  <button className="btn-sec" disabled={busy} onClick={() => call(`/api/laudos/${ult.id}`, 'PATCH', { acao: 'editar', conclusao: conclusao ?? ult.conclusao ?? '', ressalvas: ressalvas ?? ult.ressalvas ?? '' }, 'Laudo atualizado.')}>Salvar e atualizar PDF</button>
                  <button className="btn" disabled={busy} onClick={() => call(`/api/laudos/${ult.id}`, 'PATCH', { acao: 'enviar_revisao' }, 'Enviado para revisão.')}>Enviar para revisão</button>
                </div>
              </div>
            )}
            {ult.status === 'EM_REVISAO' && admin && (
              <div className="flex flex-wrap gap-2">
                <button className="btn" disabled={busy} onClick={() => call(`/api/laudos/${ult.id}`, 'PATCH', { acao: 'aprovar' }, 'Laudo aprovado. Versão final emitida.')}>Aprovar e emitir versão final</button>
                <button className="btn-bad" disabled={busy} onClick={() => { const m = prompt('Motivo da devolução:'); if (m) call(`/api/laudos/${ult.id}`, 'PATCH', { acao: 'devolver', motivo: m }, 'Laudo devolvido.'); }}>Devolver para correção</button>
              </div>
            )}
          </div>
        )}
        <table className="w-full"><tbody>
          {d.laudos.map((l: any) => (
            <tr key={l.id}><td>{l.numero} · v{l.versao}</td><td><Badge k={l.status}>{STATUS_LAUDO[l.status]}</Badge></td><td>{new Date(l.createdAt).toLocaleString('pt-BR')}</td>
              <td><a className="text-petrol underline" target="_blank" href={`/api/laudos/${l.id}/pdf`}>Abrir PDF</a>{l.status === 'APROVADO' && <span className="ml-2 text-xs">Código: {l.codigoValidacao}</span>}</td></tr>
          ))}
          {!d.laudos.length && <tr><td className="text-sm text-ink/60">Nenhum laudo gerado ainda.</td></tr>}
        </tbody></table>
      </section>

      {zoom && (
        <div className="fixed inset-0 z-50 overflow-auto bg-black/90 p-2" onClick={() => setZoom(null)} role="dialog" aria-label="Foto ampliada">
          <button className="fixed right-3 top-3 rounded bg-white px-3 py-1 text-sm font-semibold">Fechar</button>
          <img src={zoom} alt="Foto ampliada" onClick={(e) => { e.stopPropagation(); setAmpliado(!ampliado); }} className={`mx-auto ${ampliado ? 'max-w-none w-[220%] cursor-zoom-out' : 'max-h-[92vh] cursor-zoom-in'}`} />
        </div>
      )}
    </div>
  );
}

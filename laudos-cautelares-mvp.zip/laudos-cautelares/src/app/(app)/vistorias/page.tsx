import Link from 'next/link';
import { prisma } from '@/lib/db';
import { getUser } from '@/lib/auth';
import { STATUS_VISTORIA } from '@/lib/categorias';
import { normalizaPlaca } from '@/lib/regras';
import { Badge } from '@/components/ui';

type SP = { placa?: string; status?: string; peritoId?: string; de?: string; ate?: string; laudo?: string };
export default async function Lista({ searchParams: s }: { searchParams: SP }) {
  const u = (await getUser())!;
  const where: any = {};
  if (u.role === 'PERITO') where.peritoId = u.id; else if (s.peritoId) where.peritoId = s.peritoId;
  if (s.placa) where.placa = { contains: normalizaPlaca(s.placa) };
  if (s.status) where.status = s.status;
  if (s.laudo) where.laudos = { some: { numero: { contains: s.laudo, mode: 'insensitive' } } };
  if (s.de || s.ate) where.createdAt = { ...(s.de && { gte: new Date(s.de) }), ...(s.ate && { lte: new Date(s.ate + 'T23:59:59') }) };
  const [vs, peritos] = await Promise.all([
    prisma.vistoria.findMany({ where, orderBy: { createdAt: 'desc' }, take: 200, include: { perito: { select: { nome: true } }, laudos: { select: { numero: true }, take: 1 } } }),
    u.role === 'PERITO' ? [] : prisma.user.findMany({ where: { role: 'PERITO' }, select: { id: true, nome: true } }),
  ]);
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><h1 className="text-xl font-bold">Vistorias</h1><Link href="/vistorias/nova" className="btn">Nova vistoria</Link></div>
      <form className="card grid grid-cols-2 gap-3 md:grid-cols-6">
        <div><label className="lbl">Placa</label><input name="placa" defaultValue={s.placa} className="inp" /></div>
        <div><label className="lbl">Nº do laudo</label><input name="laudo" defaultValue={s.laudo} className="inp" /></div>
        <div><label className="lbl">Status</label><select name="status" defaultValue={s.status || ''} className="inp"><option value="">Todos</option>{Object.entries(STATUS_VISTORIA).map(([k, t]) => <option key={k} value={k}>{t}</option>)}</select></div>
        {u.role !== 'PERITO' && <div><label className="lbl">Perito</label><select name="peritoId" defaultValue={s.peritoId || ''} className="inp"><option value="">Todos</option>{peritos.map((p) => <option key={p.id} value={p.id}>{p.nome}</option>)}</select></div>}
        <div><label className="lbl">De</label><input type="date" name="de" defaultValue={s.de} className="inp" /></div>
        <div><label className="lbl">Até</label><input type="date" name="ate" defaultValue={s.ate} className="inp" /></div>
        <button className="btn col-span-2 md:col-span-1 md:self-end">Filtrar</button>
      </form>
      <div className="card overflow-x-auto p-0">
        <table className="w-full min-w-[640px]">
          <thead><tr><th>OS</th><th>Placa</th><th>Veículo</th><th>Perito</th><th>Data</th><th>Laudo</th><th>Status</th></tr></thead>
          <tbody>
            {vs.map((v) => (
              <tr key={v.id}>
                <td><Link className="font-semibold text-petrol underline" href={`/vistorias/${v.id}`}>{v.os}</Link></td>
                <td>{v.placa}{v.demo && <span className="ml-1 text-xs text-warn">[demo]</span>}</td>
                <td>{[v.marca, v.modelo].filter(Boolean).join(' ') || '—'}</td><td>{v.perito.nome}</td>
                <td>{v.createdAt.toLocaleDateString('pt-BR')}</td><td>{v.laudos[0]?.numero ?? '—'}</td>
                <td><Badge k={v.status}>{STATUS_VISTORIA[v.status]}</Badge></td>
              </tr>
            ))}
            {!vs.length && <tr><td colSpan={7} className="py-6 text-center text-ink/60">Nenhuma vistoria encontrada. Crie a primeira em “Nova vistoria”.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

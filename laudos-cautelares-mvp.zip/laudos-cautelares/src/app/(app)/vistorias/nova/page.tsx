'use client';
import { useState } from 'react';

export default function Nova() {
  const [erro, setErro] = useState('');
  const [busy, setBusy] = useState(false);
  async function enviar(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setErro('');
    const body = Object.fromEntries(new FormData(e.currentTarget).entries());
    for (const k of Object.keys(body)) if (body[k] === '') delete body[k];
    const r = await fetch('/api/vistorias', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    if (r.ok) { location.href = `/vistorias/${j.id}`; return; }
    setErro(j.detalhes?.placa?.[0] || j.erro || 'Não foi possível criar.'); setBusy(false);
  }
  const f = (n: string, l: string, extra: any = {}) => <div><label className="lbl" htmlFor={n}>{l}</label><input id={n} name={n} className="inp" {...extra} /></div>;
  return (
    <div className="mx-auto max-w-xl space-y-4">
      <h1 className="text-xl font-bold">Nova vistoria</h1>
      <form onSubmit={enviar} className="card space-y-3">
        {f('placa', 'Placa *', { required: true, maxLength: 8, placeholder: 'ABC1D23', autoCapitalize: 'characters' })}
        <div className="grid grid-cols-2 gap-3">{f('marca', 'Marca')}{f('modelo', 'Modelo')}</div>
        <div className="grid grid-cols-3 gap-3">{f('anoFab', 'Ano fab.', { inputMode: 'numeric' })}{f('anoModelo', 'Ano modelo', { inputMode: 'numeric' })}{f('cor', 'Cor')}</div>
        {f('cliente', 'Cliente')}{f('local', 'Local da vistoria')}
        {erro && <p role="alert" className="text-sm font-medium text-bad">{erro}</p>}
        <button className="btn w-full" disabled={busy}>{busy ? 'Criando…' : 'Criar e enviar fotos'}</button>
      </form>
    </div>
  );
}

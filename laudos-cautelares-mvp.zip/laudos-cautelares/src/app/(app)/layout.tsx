import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getUser } from '@/lib/auth';
import Logout from '@/components/Logout';

export const dynamic = 'force-dynamic';
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const u = await getUser();
  if (!u) redirect('/login');
  const links = [
    ['/painel', 'Painel'], ['/vistorias', 'Vistorias'], ['/vistorias/nova', 'Nova vistoria'],
    ...(u.role === 'ADMIN' ? [['/usuarios', 'Usuários'], ['/auditoria', 'Auditoria']] : []),
  ];
  return (
    <div className="min-h-screen md:flex">
      <aside className="bg-petrol text-white md:w-56 md:shrink-0">
        <div className="flex items-center justify-between px-4 py-3 md:block">
          <div className="font-bold">Laudos Cautelares</div>
          <div className="text-xs text-white/70">{u.nome} · {u.role === 'PERITO' ? 'Perito' : u.role === 'SEDE' ? 'Sede' : 'Administrador'}</div>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-2 pb-2 md:flex-col md:pb-0">
          {links.map(([h, t]) => <Link key={h} href={h} className="whitespace-nowrap rounded px-3 py-2 text-sm hover:bg-white/10">{t}</Link>)}
          <div className="px-3 py-2 text-white"><Logout /></div>
        </nav>
      </aside>
      <main className="min-w-0 flex-1 p-4 md:p-6">{children}</main>
    </div>
  );
}

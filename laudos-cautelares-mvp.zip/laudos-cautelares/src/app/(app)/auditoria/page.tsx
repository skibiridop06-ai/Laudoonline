import { redirect } from 'next/navigation';
import { prisma } from '@/lib/db';
import { getUser } from '@/lib/auth';

export default async function Auditoria() {
  const u = await getUser();
  if (u?.role !== 'ADMIN') redirect('/painel');
  const [logs, users] = await Promise.all([prisma.auditoria.findMany({ orderBy: { createdAt: 'desc' }, take: 300 }), prisma.user.findMany({ select: { id: true, nome: true } })]);
  const nome = new Map(users.map((x) => [x.id, x.nome]));
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold">Auditoria (últimos 300 registros)</h1>
      <div className="card overflow-x-auto p-0"><table className="w-full min-w-[720px]"><thead><tr><th>Data</th><th>Usuário</th><th>Ação</th><th>Entidade</th><th>Detalhes</th></tr></thead>
        <tbody>{logs.map((l) => <tr key={l.id}><td className="whitespace-nowrap">{l.createdAt.toLocaleString('pt-BR')}</td><td>{l.userId ? nome.get(l.userId) ?? l.userId : '—'}</td><td>{l.acao}</td><td className="text-xs">{l.entidade}</td><td className="max-w-xs break-words text-xs">{l.detalhes ? JSON.stringify(l.detalhes) : ''}</td></tr>)}</tbody></table></div>
    </div>
  );
}

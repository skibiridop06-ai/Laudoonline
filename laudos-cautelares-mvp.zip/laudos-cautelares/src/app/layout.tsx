import './globals.css';
import type { Metadata, Viewport } from 'next';

export const metadata: Metadata = { title: 'Laudos Cautelares', description: 'Plataforma de laudos cautelares veiculares', manifest: '/manifest.webmanifest' };
export const viewport: Viewport = { themeColor: '#0F4C5C', width: 'device-width', initialScale: 1 };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}

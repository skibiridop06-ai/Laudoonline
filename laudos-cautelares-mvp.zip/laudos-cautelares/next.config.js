/** @type {import('next').NextConfig} */
module.exports = {
  experimental: { serverComponentsExternalPackages: ['sharp', 'playwright', '@prisma/client', 'bcryptjs'] },
  poweredByHeader: false,
};

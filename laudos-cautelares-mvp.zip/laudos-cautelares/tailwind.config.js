/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#14212B', petrol: { DEFAULT: '#0F4C5C', dark: '#0A3641', soft: '#E3EEF0' },
        paper: '#F4F5F7', line: '#D9DEE3', ok: '#166534', warn: '#B45309', bad: '#B91C1C',
      },
      fontFamily: { sans: ['"Segoe UI"', 'system-ui', '-apple-system', 'Roboto', 'sans-serif'] },
    },
  },
  plugins: [],
};

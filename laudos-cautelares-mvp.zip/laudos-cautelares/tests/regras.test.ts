import { describe, it, expect } from 'vitest';
import { normalizaPlaca, placaValida, placaDivergente, statusCampo, faltantes, paraRegra, camposPendentes } from '@/lib/regras';
import { OBRIGATORIAS } from '@/lib/categorias';

describe('placa', () => {
  it('normaliza e valida padrão antigo e Mercosul', () => {
    expect(normalizaPlaca('abc-1d23')).toBe('ABC1D23');
    expect(placaValida('ABC1234')).toBe(true);
    expect(placaValida('ABC1D23')).toBe(true);
    expect(placaValida('AB12')).toBe(false);
  });
  it('detecta divergência ignorando formatação', () => {
    expect(placaDivergente('abc-1234', 'ABC1234')).toBe(false);
    expect(placaDivergente('ABC1235', 'ABC1234')).toBe(true);
    expect(placaDivergente(null, 'ABC1234')).toBe(false);
  });
});

describe('statusCampo', () => {
  it('nunca marca valor vazio como identificado', () => {
    expect(statusCampo(null, 0.99)).toBe('NAO_IDENTIFICADO');
    expect(statusCampo('  ', 0.99)).toBe('NAO_IDENTIFICADO');
  });
  it('baixa confiança exige conferência', () => {
    expect(statusCampo('123', 0.5)).toBe('NECESSITA_CONFERENCIA');
    expect(statusCampo('123', 0.9)).toBe('IDENTIFICADO');
  });
});

describe('faltantes', () => {
  const ok = (c: string) => ({ categoria: c, legivel: true, duplicada: false });
  it('lista tudo quando não há fotos', () => expect(faltantes([])).toEqual(OBRIGATORIAS));
  it('ignora ilegíveis e duplicadas', () => {
    const r = faltantes([{ categoria: 'FRONTAL', legivel: false, duplicada: false }, { categoria: 'TRASEIRA', legivel: true, duplicada: true }, ok('PLACA')]);
    expect(r).toContain('FRONTAL'); expect(r).toContain('TRASEIRA'); expect(r).not.toContain('PLACA');
  });
  it('vazio quando todas obrigatórias presentes', () => expect(faltantes(OBRIGATORIAS.map(ok))).toEqual([]));
});

describe('paraRegra', () => {
  const base = { categoriaConfirmada: null, categoriaSugerida: 'FRONTAL', confCategoria: 0.5, legivel: true, duplicadaDe: null };
  it('sugestão com baixa confiança não conta', () => expect(paraRegra(base).categoria).toBeNull());
  it('confirmação humana sempre conta', () => expect(paraRegra({ ...base, categoriaConfirmada: 'TRASEIRA', legivel: false })).toMatchObject({ categoria: 'TRASEIRA', legivel: true }));
});

describe('camposPendentes', () => {
  it('só CONFIRMADO e NAO_IDENTIFICADO não bloqueiam', () => {
    const p = camposPendentes([{ status: 'CONFIRMADO' }, { status: 'NAO_IDENTIFICADO' }, { status: 'IDENTIFICADO' }, { status: 'NECESSITA_CONFERENCIA' }]);
    expect(p).toHaveLength(2);
  });
});
